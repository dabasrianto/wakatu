// Variabel untuk menampung waktu dan opsi
let clock = document.getElementById("clock");
let timeOptions = document.getElementById("time-options");
let hour12 = true;
let fontSize = 48;
let fontColor = "#444";
let backgroundColor = "#f0f0f0";

// Fungsi untuk update waktu
function updateClock() {
	let now = new Date();
	let hours = now.getHours();
	let minutes = now.getMinutes();
	let seconds = now.getSeconds();

	if (hour12) {
		hours = hours % 12;
		if (hours == 0) hours = 12;
	} else {
		hours = now.getHours();
	}

	clock.textContent = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
}

// Fungsi untuk mengubah font size
function increaseFontSize() {
	fontSize += 2;
	clock.style.fontSize = `${fontSize}px`;
}

function decreaseFontSize() {
	fontSize -= 2;
	clock.style.fontSize = `${fontSize}px`;
}

// Fungsi untuk mengubah font color
function changeFontColor() {
	fontColor = prompt("Enter font color (hex code):");
	clock.style.color = fontColor;
}

// Fungsi untuk mengubah background color
function changeBackgroundColor() {
	backgroundColor = prompt("Enter background color (hex code):");
	document.body.style.background = backgroundColor;
}

// Fungsi untuk mengubah jam 12/24
function changeHourFormat() {
	hour12 = !hour12;
	updateClock();
}

// Fungsi untuk mengubah layout
function changeLayout() {
	timeOptions.style.position = "relative";
	timeOptions.style.top = "0";
	timeOptions.style.right = "0";
	timeOptions.style.padding = "10px";
}

// Fungsi untuk mempadatkan digit
function pad(num) {
	return (num < 10 ? "0" : "") + num;
}

// Mengatur interval untuk update waktu
setInterval(updateClock, 1000);

// Mengatur event listener untuk button
document.getElementById("12hour-btn").addEventListener("click", changeHourFormat);
document.getElementById("24hour-btn").addEventListener("click", changeHourFormat);
document.getElementById("increase-btn").addEventListener("click", increaseFontSize);
document.getElementById("decrease-btn").addEventListener("click", decreaseFontSize);
document.getElementById("font-btn").addEventListener("click", changeFontColor);
document.getElementById("color-btn").addEventListener("click", changeBackgroundColor);
document.getElementById("bg-btn").addEventListener("click", changeBackgroundColor);